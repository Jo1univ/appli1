$(document).ready(function(){
    $("#button").click(function(){
        $.ajax({
		url: 'http://127.0.0.1/scripts/dossierTest/test.php',
		type: 'GET',
		
		success: function(data) {
			//called when successful
			$("#result").html(data);
		},
		error: function(e) {
			$("#result").html("erreur " +e);
		}
		});
	});
});